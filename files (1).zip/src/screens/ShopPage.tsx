import React from "react";
import styled from "styled-components";
import { useGame } from "../GameContext";
import { shopItems } from "../gameData";
import SoundManager from "../SoundManager";

const ShopContainer = styled.div`
  padding: 22px 10px;
  background: #f8fcff;
  min-height: 500px;
`;

const ItemRow = styled.div`
  display: flex;
  align-items: center;
  background: #f4fcf8;
  padding: 12px;
  border-radius: 12px;
  margin-bottom: 12px;
  box-shadow: 0 1px 4px #0001;
`;

const Icon = styled.span`
  font-size: 2rem;
  margin-left: 14px;
`;

const Details = styled.div`
  flex: 1;
`;

const BuyBtn = styled.button`
  background: #81d4fa;
  color: #222;
  font-size: 1.1rem;
  padding: 5px 16px;
  border-radius: 16px;
  border: none;
  cursor: pointer;
  margin-right: 10px;
  &:disabled {
    background: #bbb;
    color: #fff;
    cursor: not-allowed;
  }
`;

const BackBtn = styled.button`
  background: #e2f0cb;
  color: #222;
  font-size: 1.1rem;
  padding: 6px 16px;
  border-radius: 18px;
  margin-bottom: 22px;
  border: none;
`;

export default function ShopPage() {
  const { setScreen, gameState, updateUser } = useGame();
  const { user } = gameState;

  function buyItem(key: string, cost: number) {
    if (!user) return;
    if (user.coins < cost) return;
    updateUser({
      coins: user.coins - cost,
      shopInventory: {
        ...user.shopInventory,
        [key]: (user.shopInventory[key] || 0) + 1,
      }
    });
    SoundManager.play("shop");
    alert("הרכישה בוצעה בהצלחה!");
  }

  return (
    <ShopContainer>
      <BackBtn onClick={() => setScreen("level-select")}>⬅️ חזרה</BackBtn>
      <h2>חנות</h2>
      <div>
        {shopItems.map(item =>
          <ItemRow key={item.key}>
            <Icon>{item.icon}</Icon>
            <Details>
              <b>{item.name}</b>
              <div style={{fontSize: "1rem"}}>{item.desc}</div>
              <div style={{fontSize: "0.95rem", color: "#388"}}>מחיר: {item.cost} מטבעות</div>
            </Details>
            <BuyBtn
              disabled={!user || user.coins < item.cost}
              onClick={() => buyItem(item.key, item.cost)}
            >קנה</BuyBtn>
          </ItemRow>
        )}
      </div>
      <div style={{marginTop: 22, fontSize: "1.1rem"}}>
        יש לך <b>{user?.coins || 0}</b> מטבעות
      </div>
    </ShopContainer>
  );
}