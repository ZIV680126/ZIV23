import React, { useEffect, useState } from "react";
import styled, { keyframes } from "styled-components";
import { useGame } from "../GameContext";
import { getAllLevels, shopItems } from "../gameData";
import SoundManager from "../SoundManager";

const Container = styled.div`
  padding: 12px 0 12px 0;
  background: #f8fcff;
  min-height: 500px;
  text-align: center;
`;

const StageTitle = styled.h3`
  font-size: 1.5rem;
  color: #2176ae;
`;

const QuestionBox = styled.div`
  background: #f1f8e9;
  border-radius: 14px;
  padding: 18px 8px;
  margin: 12px 0;
  box-shadow: 0 1px 4px #0001;
`;

const AnswersRow = styled.div`
  display: flex;
  flex-direction: row-reverse;
  gap: 16px;
  margin: 18px 0;
`;

const AnswerBtn = styled.button<{ selected: boolean }>`
  background: ${({ selected }) => selected ? "#97dffc" : "#fff"};
  color: #2176ae;
  border-radius: 14px;
  font-size: 1.1rem;
  border: 2px solid #97dffc;
  min-width: 76px;
  padding: 12px 8px;
  cursor: pointer;
  margin: 0 0 0 0;
  box-shadow: 0 1px 6px #0001;
  transition: background .18s;
`;

const ShopBar = styled.div`
  margin: 6px 0 0 0;
  display: flex;
  flex-direction: row-reverse;
  gap: 10px;
  align-items: center;
  justify-content: center;
`;

const ShopItemBtn = styled.button`
  background: #fefefe;
  color: #2176ae;
  border: 1.5px solid #97dffc;
  border-radius: 10px;
  font-size: 1.2rem;
  margin: 0 2px;
  padding: 4px 11px;
  cursor: pointer;
  transition: background .11s;
`;

const NextBtn = styled.button`
  background: #8ae99f;
  color: #222;
  font-size: 1.2rem;
  padding: 10px 28px;
  border-radius: 13px;
  margin: 15px 0 0 0;
  font-weight: bold;
  border: none;
  box-shadow: 0 2px 8px #0001;
  cursor: pointer;
`;

const BackBtn = styled.button`
  background: #e2f0cb;
  color: #222;
  font-size: 1.05rem;
  padding: 5px 17px;
  border-radius: 12px;
  margin: 3px 0 0 0;
  border: none;
`;

const StageNumBtn = styled.button`
  background: #f7fcff;
  color: #2176ae;
  border: 1.5px solid #97dffc;
  border-radius: 10px;
  font-size: 1.08rem;
  margin: 0 4px;
  min-width: 34px;
  cursor: pointer;
  padding: 5.5px 0;
`;

const StageNavBar = styled.div`
  margin-bottom: 8px;
`;

const Animation = keyframes`
  0% { transform: scale(1);}
  60% { transform: scale(1.13);}
  100% { transform: scale(1);}
`;

const AchievementPop = styled.div`
  background: #ffe082;
  color: #fff;
  font-size: 1.2rem;
  border-radius: 16px;
  position: absolute;
  left: 0; right: 0;
  top: 40px;
  width: 70%;
  margin: 0 auto;
  padding: 16px;
  box-shadow: 0 2px 18px #0002;
  animation: ${Animation} 1s;
  z-index: 444;
`;

export default function StagePage() {
  const { gameState, setScreen, setCurrentStage, updateUser } = useGame();
  const { user, currentLevel, currentStage } = gameState;
  const levels = getAllLevels();
  const level = levels[currentLevel];
  const stage = level.stages[currentStage];
  const questions = stage.questions;
  const [qIdx, setQIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answers, setAnswers] = useState<(number|null)[]>(Array(questions.length).fill(null));
  const [score, setScore] = useState(0);
  const [showNext, setShowNext] = useState(false);
  const [shopMsg, setShopMsg] = useState("");
  const [achPop, setAchPop] = useState<string | null>(null);
  const [hintShown, setHintShown] = useState(false);

  useEffect(() => {
    setQIdx(0);
    setSelected(null);
    setAnswers(Array(questions.length).fill(null));
    setScore(0);
    setShowNext(false);
    setHintShown(false);
  }, [currentStage]);

  function handleAnswer(idx: number) {
    if (selected !== null) return;
    setSelected(idx);
    let correct = idx === questions[qIdx].correct;
    setTimeout(() => {
      setAnswers(ans => {
        let newAns = [...ans];
        newAns[qIdx] = idx;
        return newAns;
      });
      setScore(s => correct ? s + 1 : s);
      setShowNext(true);
      SoundManager.play(correct ? "correct" : "wrong");
    }, 360);
  }

  function handleNext() {
    if (qIdx < questions.length - 1) {
      setQIdx(qIdx + 1);
      setSelected(null);
      setShowNext(false);
      setHintShown(false);
    } else {
      // שלב הסתיים
      let stageKey = `${currentLevel}-${currentStage}`;
      let userStages = { ...user!.perStageAnswers };
      userStages[stageKey] = answers.map((ans, i) => ans === questions[i].correct);
      let levelProgress = [...user!.levelProgress];
      if (levelProgress[currentLevel] < currentStage + 1) levelProgress[currentLevel] = currentStage + 1;
      // זכיה במטבעות ונקודות
      let coinsAwarded = Math.floor((score / questions.length) * 25) + 5;
      let ptsAwarded = Math.floor((score / questions.length) * 100);
      updateUser({
        perStageAnswers: userStages,
        levelProgress,
        coins: user!.coins + coinsAwarded,
        points: user!.points + ptsAwarded,
      });
      // הישגים - דוגמת פותר ראשון
      if (!user!.achievements.includes("first")) {
        updateUser({ achievements: [...user!.achievements, "first"] });
        setAchPop("🎯 פותר ראשון! פתחת הישג!");
        SoundManager.play("achievement");
      }
      setTimeout(() => {
        setScreen("level-select");
      }, 1700);
      SoundManager.play("levelup");
    }
  }

  // שלבים ניתנים ללחיצה מחדש
  function handleStageNumClick(idx: number) {
    setCurrentStage(idx);
    setQIdx(0);
    setSelected(null);
    setAnswers(Array(questions.length).fill(null));
    setScore(0);
    setShowNext(false);
    setHintShown(false);
    SoundManager.play("shop");
  }

  // חנות - סרגל משתמש
  function useShopItem(key: string) {
    if (!user || !user.shopInventory[key]) return;
    if (key === "hint") {
      setHintShown(true);
      updateUser({ shopInventory: { ...user.shopInventory, [key]: user.shopInventory[key] - 1 } });
      setShopMsg("💡 רמז הופעל!");
    } else if (key === "reveal") {
      setSelected(questions[qIdx].correct);
      updateUser({ shopInventory: { ...user.shopInventory, [key]: user.shopInventory[key] - 1 } });
      setShopMsg("🔍 תשובה נחשפה!");
      setTimeout(() => handleNext(), 1400);
    } else if (key === "luck") {
      updateUser({ shopInventory: { ...user.shopInventory, [key]: user.shopInventory[key] - 1 } });
      if (Math.random() < 0.5) {
        let reward = Math.random() < .6 ? 30 : 60;
        updateUser({ coins: user.coins + reward });
        setShopMsg(`🍀 זכית ב-${reward} מטבעות!`);
        SoundManager.play("lucksuccess");
      } else {
        setShopMsg("🍀 לא זכית הפעם");
        SoundManager.play("luckfail");
      }
    } else if (key === "double") {
      updateUser({ shopInventory: { ...user.shopInventory, [key]: user.shopInventory[key] - 1 } });
      setShopMsg("✨ תקבל פי 2 נקודות בסוף שלב זה!");
    }
    setTimeout(() => setShopMsg(""), 2000);
  }

  // ערבוב תשובות בכל שלב
  function getShuffledAnswers(qIdx: number) {
    const arr = questions[qIdx].answers.map((ans, idx) => ({ ans, idx }));
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  return (
    <Container>
      <BackBtn onClick={() => setScreen("level-select")}>⬅️ חזרה</BackBtn>
      <StageNavBar>
        {level.stages.map((st, i) =>
          <StageNumBtn key={i} onClick={() => handleStageNumClick(i)}>{i + 1}</StageNumBtn>
        )}
      </StageNavBar>
      <StageTitle>{stage.title}</StageTitle>
      <ShopBar>
        {shopItems.map(item => (
          <ShopItemBtn
            key={item.key}
            disabled={!user || !user.shopInventory[item.key]}
            onClick={() => useShopItem(item.key)}
          >
            {item.icon} ×{user?.shopInventory[item.key] || 0}
          </ShopItemBtn>
        ))}
      </ShopBar>
      <QuestionBox>
        <div style={{ fontSize: "1.18rem" }}>{questions[qIdx].text}</div>
        {hintShown && questions[qIdx].hint && (
          <div style={{ color: "#234", fontSize: ".95rem", marginTop: 8 }}>{questions[qIdx].hint}</div>
        )}
        <AnswersRow>
          {getShuffledAnswers(qIdx).map(({ ans, idx }) =>
            <AnswerBtn
              key={idx}
              selected={selected === idx}
              onClick={() => handleAnswer(idx)}
            >{ans}</AnswerBtn>
          )}
        </AnswersRow>
        {showNext && <NextBtn onClick={handleNext}>המשך</NextBtn>}
      </QuestionBox>
      <div style={{ marginTop: 10 }}>
        שאלה {qIdx + 1} מתוך {questions.length}
      </div>
      <div style={{ marginTop: 14, color: "#666", minHeight: 22 }}>{shopMsg}</div>
      {achPop && <AchievementPop>{achPop}</AchievementPop>}
    </Container>
  );
}