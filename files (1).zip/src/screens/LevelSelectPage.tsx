import React from "react";
import styled from "styled-components";
import { useGame } from "../GameContext";
import { getAllLevels } from "../gameData";
import SoundManager from "../SoundManager";

const Container = styled.div`
  padding: 22px 0 12px 0;
  background: #f8fcff;
  min-height: 500px;
  text-align: center;
`;

const LevelBtn = styled.button<{ unlocked: boolean; color: string; }>`
  background: ${({ color }) => color};
  color: #222;
  font-size: 1.3rem;
  margin: 12px 8px;
  padding: 18px 30px;
  border-radius: 18px;
  border: 2px solid #2222;
  cursor: ${({ unlocked }) => unlocked ? "pointer" : "not-allowed"};
  opacity: ${({ unlocked }) => unlocked ? 1 : 0.35};
  box-shadow: 0 2px 10px #0001;
  min-width: 135px;
`;

const Progress = styled.div`
  margin-top: 10px;
  color: #2176ae;
`;

const ShopBtn = styled.button`
  background: #e2f0cb;
  color: #222;
  font-size: 1.1rem;
  padding: 7px 20px;
  border-radius: 18px;
  margin: 6px 0 0 0;
  border: none;
  cursor: pointer;
  transition: background .15s;
  margin-bottom: 12px;
`;

export default function LevelSelectPage() {
  const { setCurrentLevel, setScreen, gameState } = useGame();
  const { user } = gameState;
  const levels = getAllLevels();

  function handleLevelClick(idx: number) {
    if (user && (idx === 0 || user.levelProgress[idx-1] >= levels[idx-1].stages.length)) {
      setCurrentLevel(idx);
      setScreen("stage");
      SoundManager.play("shop");
    }
  }

  return (
    <Container>
      <h2>בחר רמת קושי</h2>
      <ShopBtn onClick={() => setScreen("shop")}>לחנות 🛒</ShopBtn>
      {levels.map((lvl, i) => {
        const unlocked = i === 0 || (user && user.levelProgress[i-1] >= levels[i-1].stages.length);
        const completed = user && user.levelProgress[i] >= lvl.stages.length;
        return (
          <div key={i}>
            <LevelBtn
              color={lvl.color}
              unlocked={unlocked}
              onClick={() => handleLevelClick(i)}
            >
              {lvl.name} {completed ? "✅" : ""}
            </LevelBtn>
            <Progress>
              שלבים שהושלמו: {user ? user.levelProgress[i] : 0} / {lvl.stages.length}
            </Progress>
          </div>
        );
      })}
    </Container>
  );
}