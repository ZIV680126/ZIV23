import React, { useState } from "react";
import styled, { keyframes } from "styled-components";
import { useGame } from "../GameContext";
import { newUserState, loadUser, saveUser } from "../userStorage";
import SoundManager from "../SoundManager";

const bounce = keyframes`
  0% { transform: translateY(0);}
  50% { transform: translateY(-12px);}
  100% { transform: translateY(0);}
`;

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 32px 16px 0 16px;
  min-height: 500px;
  background: #e1f5fe;
`;

const Title = styled.h1`
  font-size: 2.5rem;
  color: #1c5d99;
  margin-top: 24px;
  margin-bottom: 12px;
  text-shadow: 2px 2px 0 #fff8;
`;

const InputBox = styled.input`
  font-size: 1.3rem;
  border-radius: 8px;
  border: 2px solid #85b9ed;
  padding: 10px 14px;
  margin: 8px 0;
  text-align: center;
`;

const Button = styled.button`
  background: #7ee8fa;
  color: #222;
  font-size: 1.25rem;
  padding: 10px 36px;
  border-radius: 22px;
  margin-top: 10px;
  font-weight: bold;
  border: none;
  box-shadow: 0 2px 8px #0001;
  cursor: pointer;
  transition: background .2s;
  &:hover {
    background: #2ebf91;
    color: #fff;
  }
`;

const UserList = styled.div`
  margin-top: 18px;
  width: 100%;
  max-width: 340px;
`;

const UserItem = styled.div`
  padding: 8px 12px;
  margin-bottom: 8px;
  background: #f7fafd;
  border-radius: 8px;
  font-size: 1.1rem;
  cursor: pointer;
  box-shadow: 0 1px 2px #0001;
  &:hover {
    background: #e3ffef;
  }
`;

const InfoText = styled.div`
  color: #2176ae;
  font-size: 1.1rem;
  margin-top: 14px;
`;

export default function HomePage() {
  const { setScreen, setUser, reloadUser, gameState, updateUser } = useGame();
  const [name, setName] = useState("");
  const [showList, setShowList] = useState(false);

  // טען שמות
  const userNames = Object.keys(localStorage.getItem("gomath-users") ? JSON.parse(localStorage.getItem("gomath-users")!) : {});

  function onStart() {
    if (!name.trim()) return;
    reloadUser(name.trim());
    setTimeout(() => {
      setScreen("level-select");
    }, 600);
    SoundManager.play("shop");
  }

  return (
    <Container>
      <Title>🧮 Math GO!</Title>
      <InfoText>הכניסו את שמכם כדי להתחיל לשחק:</InfoText>
      <InputBox
        placeholder="הכנס שם..."
        value={name}
        onChange={e => setName(e.target.value)}
        onFocus={() => setShowList(true)}
        onBlur={() => setTimeout(()=>setShowList(false), 250)}
      />
      <Button onClick={onStart}>התחל לשחק</Button>
      {showList && userNames.length > 0 && (
        <UserList>
          <b>משתמשים קיימים:</b>
          {userNames.map(usr => <UserItem key={usr} onClick={()=>{setName(usr); setShowList(false);}}>{usr}</UserItem>)}
        </UserList>
      )}
      <InfoText>קבלו מטבעות, נקודות והישגים על כל שלב שתסיימו!</InfoText>
    </Container>
  );
}