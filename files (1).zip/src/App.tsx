import React, { useEffect, useState } from "react";
import styled, { createGlobalStyle, keyframes } from "styled-components";
import { GameProvider, useGame } from "./GameContext";
import HomePage from "./screens/HomePage";
import LevelSelectPage from "./screens/LevelSelectPage";
import StagePage from "./screens/StagePage";
import ShopPage from "./screens/ShopPage";
import AchievementsModal from "./components/AchievementsModal";
import SoundManager from "./SoundManager";
import RobotIntro from "./components/RobotIntro";

// ======= GLOBAL STYLES =======
const GlobalStyle = createGlobalStyle`
  body {
    direction: rtl;
    font-family: 'Heebo', 'Alef', Arial, sans-serif;
    background: linear-gradient(135deg, #f8fffa 0%, #d4eaff 100%);
    min-height: 100vh;
    margin: 0;
    padding: 0;
    color: #222;
    user-select: none;
  }
`;

// ======= APP CONTAINER =======
const AppContainer = styled.div`
  min-height: 100vh;
  max-width: 500px;
  margin: 0 auto;
  background: #ffffffcc;
  box-shadow: 0 0 20px #0002;
  border-radius: 14px;
  overflow: hidden;
  position: relative;
`;

const Footer = styled.footer`
  font-size: 1rem;
  text-align: center;
  color: #888;
  margin: 20px 0 8px 0;
`;

function App() {
  return (
    <GameProvider>
      <GlobalStyle />
      <AppContainer>
        <MainRouter />
        <Footer>זכויות היוצרים שמורות לזיו סמולקין</Footer>
      </AppContainer>
    </GameProvider>
  );
}

// ======= ROUTER =======
function MainRouter() {
  const { gameState } = useGame();
  const { showAchievements, setShowAchievements, screen, showRobotIntro } = gameState;

  if (showRobotIntro) return <RobotIntro />;
  if (showAchievements) return <AchievementsModal onClose={() => setShowAchievements(false)} />;
  switch (screen) {
    case "home":
      return <HomePage />;
    case "level-select":
      return <LevelSelectPage />;
    case "stage":
      return <StagePage />;
    case "shop":
      return <ShopPage />;
    default:
      return <HomePage />;
  }
}

export default App;