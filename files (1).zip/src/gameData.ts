// ==== DATA MODELS ====
export type Question = {
  text: string;
  answers: string[];
  correct: number;
  hint?: string;
}
export type Stage = {
  title: string;
  questions: Question[];
  topic: string;
}
export type Level = {
  name: string;
  stages: Stage[];
  color: string;
};

export type Achievement = {
  key: string;
  label: string;
  desc: string;
  emoji: string;
};

export type ShopItem = {
  key: string;
  name: string;
  cost: number;
  desc: string;
  icon: string;
}

// ==== LEVELS DATA ====
export function getAllLevels(): Level[] {
  return [
    {
      name: "קל",
      color: "#8ae99f",
      stages: [
        {
          title: "חיבור דו-ספרתי",
          topic: "חיבור",
          questions: [
            { text: "12 + 17 = ?", answers: ["29", "31", "28", "27"], correct: 0, hint: "חבר עשרות ואחדות" },
            { text: "23 + 15 = ?", answers: ["36", "38", "39", "37"], correct: 1 },
            { text: "45 + 22 = ?", answers: ["67", "57", "62", "66"], correct: 0 },
            { text: "31 + 19 = ?", answers: ["50", "49", "48", "51"], correct: 0 },
            { text: "27 + 36 = ?", answers: ["63", "61", "62", "64"], correct: 0 },
          ]
        },
        {
          title: "חיסור",
          topic: "חיסור",
          questions: [
            { text: "38 - 14 = ?", answers: ["24", "23", "22", "25"], correct: 0 },
            { text: "45 - 19 = ?", answers: ["26", "27", "25", "24"], correct: 0 },
            { text: "60 - 32 = ?", answers: ["28", "27", "29", "30"], correct: 0 },
            { text: "51 - 25 = ?", answers: ["26", "27", "28", "25"], correct: 0 },
            { text: "34 - 16 = ?", answers: ["18", "17", "19", "20"], correct: 0 },
          ]
        },
        {
          title: "לוח כפל",
          topic: "כפל",
          questions: [
            { text: "6 × 7 = ?", answers: ["42", "36", "48", "54"], correct: 0 },
            { text: "4 × 8 = ?", answers: ["32", "28", "24", "30"], correct: 0 },
            { text: "5 × 9 = ?", answers: ["45", "40", "35", "50"], correct: 0 },
            { text: "8 × 3 = ?", answers: ["24", "21", "27", "18"], correct: 0 },
            { text: "7 × 5 = ?", answers: ["35", "30", "40", "25"], correct: 0 },
          ]
        },
        // ... המשך שלבים נוספים ברמה 1 (סה"כ 20 שלבים)
        {
          title: "חילוק בסיסי",
          topic: "חילוק",
          questions: [
            { text: "16 ÷ 4 = ?", answers: ["4", "5", "3", "6"], correct: 0 },
            { text: "24 ÷ 6 = ?", answers: ["4", "3", "5", "6"], correct: 0 },
            { text: "18 ÷ 3 = ?", answers: ["6", "5", "7", "4"], correct: 0 },
            { text: "35 ÷ 7 = ?", answers: ["5", "6", "4", "3"], correct: 0 },
            { text: "20 ÷ 5 = ?", answers: ["4", "5", "3", "2"], correct: 0 },
          ]
        },
        {
          title: "קריאת מספרים גדולים",
          topic: "מספרים גדולים",
          questions: [
            { text: "מהו המספר: 4,205?", answers: ["ארבעת אלפים ומאתיים וחמש", "ארבעת אלפים וחמש", "ארבע מאות וחמש", "ארבעת אלפים וחמישים"], correct: 0 },
            { text: "מהו המספר: 3,029?", answers: ["שלושת אלפים ועשרים ותשע", "שלוש מאות ועשרים ותשע", "שלושת אלפים ומאה עשרים ותשע", "שלוש מאות ותשע"], correct: 0 },
            { text: "מהו המספר: 7,110?", answers: ["שבעת אלפים ומאה ועשר", "שבע מאות ועשר", "שבעת אלפים ומאה", "שבעת אלפים ועשרים"], correct: 0 },
            { text: "מהו המספר: 5,500?", answers: ["חמשת אלפים וחמש מאות", "חמש מאות וחמישים", "חמש מאות וחמש", "חמשת אלפים וחמישים"], correct: 0 },
            { text: "מהו המספר: 9,999?", answers: ["תשעת אלפים ותשע מאות תשעים ותשע", "תשע מאות תשעים ותשע", "תשעת אלפים ותשע מאות", "תשעת אלפים ומאה"], correct: 0 },
          ]
        },
        // ... הוסף שלבים נוספים לפי פירוט הדרישה
      ]
    },
    {
      name: "בינוני",
      color: "#97dffc",
      stages: [
        {
          title: "כפל דו-ספרתי בחד-ספרתי",
          topic: "כפל",
          questions: [
            { text: "12 × 4 = ?", answers: ["48", "36", "42", "56"], correct: 0 },
            { text: "17 × 3 = ?", answers: ["51", "41", "47", "45"], correct: 0 },
            { text: "15 × 6 = ?", answers: ["90", "80", "85", "96"], correct: 0 },
            { text: "13 × 5 = ?", answers: ["65", "60", "70", "75"], correct: 0 },
            { text: "19 × 2 = ?", answers: ["38", "36", "40", "32"], correct: 0 },
          ]
        },
        // ... המשך שלבים (סה"כ ~20 שלבים)
      ]
    },
    {
      name: "קשה",
      color: "#ffb677",
      stages: [
        {
          title: "כפל דו-ספרתי מלא",
          topic: "כפל",
          questions: [
            { text: "17 × 12 = ?", answers: ["204", "144", "184", "201"], correct: 0 },
            { text: "21 × 18 = ?", answers: ["378", "338", "352", "396"], correct: 0 },
            { text: "35 × 11 = ?", answers: ["385", "385", "355", "345"], correct: 0 },
            { text: "23 × 17 = ?", answers: ["391", "371", "381", "401"], correct: 0 },
            { text: "29 × 13 = ?", answers: ["377", "387", "379", "359"], correct: 0 },
          ]
        },
        // ... המשך שלבים (סה"כ ~20 שלבים)
      ]
    },
    {
      name: "משוגע",
      color: "#fb7299",
      stages: [
        {
          title: "חשיבה מתמטית",
          topic: "חשיבה מתמטית",
          questions: [
            { text: "מה המספר הבא בסדרה: 2, 4, 8, 16, ?", answers: ["32", "24", "18", "20"], correct: 0 },
            { text: "אם רותי קנתה 3 עטים במחיר 5 ש\"ח כל אחד, כמה שילמה בסך הכל?", answers: ["15", "18", "13", "10"], correct: 0 },
            { text: "איזו מהאפשרויות היא מספר ראשוני?", answers: ["7", "9", "15", "21"], correct: 0 },
            { text: "אם יש 4 קופסאות ובכל קופסה 6 תפוחים, כמה תפוחים בסך הכל?", answers: ["24", "20", "18", "30"], correct: 0 },
            { text: "איזו קבוצה מכילה מספר זוגי של פריטים: [3, 5, 7], [2, 4, 6], [1, 3, 5], [5, 7, 9]", answers: ["[2, 4, 6]", "[3, 5, 7]", "[1, 3, 5]", "[5, 7, 9]"], correct: 0 },
          ]
        },
        // ... המשך שלבים (סה"כ ~20 שלבים)
      ]
    },
  ];
}

// ==== ACHIEVEMENTS ====
export const allAchievements: Achievement[] = [
  { key: "first", label: "פותר ראשון", desc: "פתרת את החידה הראשונה שלך! פתח", emoji: "🎯" },
  { key: "5-math", label: "מתמטיקאי מתחיל", desc: "פתרת 5 חידות מתמטיקה! לא נעול", emoji: "📊" },
  { key: "plus3", label: "אלוף חיבור", desc: "פתר 3 חידות חיבור ברצף! לא נעול", emoji: "➕" },
  { key: "minus3", label: "מלך חיסור", desc: "פתר 3 חידות חיסור ברצף! לא נעול", emoji: "➖" },
  { key: "mult-all", label: "גאון כפל", desc: "פתר את כל חידות הכפל! לא נעול", emoji: "✖️" },
  { key: "div-all", label: "אמן חילוק", desc: "פתר את כל חידות החילוק! לא נעול", emoji: "➗" },
  { key: "star-week", label: "כוכב השבוע", desc: "פתר חידה נבחרת השבוע! לא נעול", emoji: "⭐" },
  { key: "1000pts", label: "כוכב על", desc: "צברת 1000 נקודות! לא נעול", emoji: "🌟" },
  { key: "persist7", label: "מתמיד", desc: "פתר חידות 7 ימים ברציפות! לא נעול", emoji: "🔥" },
  { key: "legend", label: "אגדה", desc: "השלים את כל הרמות! לא נעול", emoji: "👑" },
];

// ==== SHOP ====
export const shopItems: ShopItem[] = [
  { key: "hint", name: "רמז", cost: 30, desc: "קבל רמז לתרגיל הנוכחי!", icon: "💡" },
  { key: "reveal", name: "גלה תשובה", cost: 50, desc: "גלה תשובה נכונה אחת בשלב!", icon: "🔍" },
  { key: "luck", name: "נקודות מזל", cost: 40, desc: "50% סיכוי לקבל פרס או כלום!", icon: "🍀" },
  { key: "double", name: "נקודות כפולות", cost: 60, desc: "קבל פי 2 נקודות בסוף שלב!", icon: "✨" },
];