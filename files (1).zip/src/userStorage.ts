// ניהול משתמשים localStorage

export type UserState = {
  name: string;
  coins: number;
  points: number;
  achievements: string[];
  levelProgress: number[]; // לכל רמה: מספר שלבים שהושלמו
  perStageAnswers: { [key: string]: boolean[] }; // "level-stage": [true, false...]
  shopInventory: { [key: string]: number };
  lastLogin: string;
};

export function newUserState(name: string): UserState {
  return {
    name,
    coins: 0,
    points: 0,
    achievements: [],
    levelProgress: [0,0,0,0],
    perStageAnswers: {},
    shopInventory: {},
    lastLogin: new Date().toISOString(),
  };
}

const STORAGE_KEY = "gomath-users";

export function saveUser(user: UserState) {
  let users = loadAllUsers();
  users[user.name] = user;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
}

export function loadUser(name: string): UserState {
  let users = loadAllUsers();
  if (users[name]) return users[name];
  return newUserState(name);
}

export function loadAllUsers(): { [name: string]: UserState } {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
  } catch {
    return {};
  }
}