// ניהול סאונדים מקצועי עם שליטה בעוצמה, טעינה מראש, ומניעת חפיפה

type SoundKey =
  | "correct"
  | "wrong"
  | "achievement"
  | "levelup"
  | "finish"
  | "shop"
  | "lucksuccess"
  | "luckfail";

const sounds: Record<SoundKey, string> = {
  correct: "/sounds/correct.mp3",
  wrong: "/sounds/wrong.mp3",
  achievement: "/sounds/achievement.mp3",
  levelup: "/sounds/levelup.mp3",
  finish: "/sounds/finish.mp3",
  shop: "/sounds/shop.mp3",
  lucksuccess: "/sounds/lucksuccess.mp3",
  luckfail: "/sounds/luckfail.mp3",
};

const audios: Partial<Record<SoundKey, HTMLAudioElement>> = {};

class SoundManager {
  static volume = 0.6;

  // הטענה מראש
  static preload() {
    (Object.keys(sounds) as SoundKey[]).forEach((key) => {
      const audio = new Audio(sounds[key]);
      audio.volume = SoundManager.volume;
      audios[key] = audio;
      audio.load();
    });
  }

  // ניגון עם מניעת חפיפה
  static play(name: SoundKey, options?: { forceRestart?: boolean }) {
    let audio = audios[name];
    // אם לא טעון, טען
    if (!audio) {
      audio = new Audio(sounds[name]);
      audio.volume = SoundManager.volume;
      audios[name] = audio;
    }
    // אם מתנגן — עצור (אם forceRestart)
    if (!audio.paused && options?.forceRestart) {
      audio.pause();
      audio.currentTime = 0;
    }
    // נגן סאונד
    audio.currentTime = 0;
    audio.volume = SoundManager.volume;
    audio.play();
  }

  // שליטה בעוצמה
  static setVolume(vol: number) {
    SoundManager.volume = vol;
    Object.values(audios).forEach((audio) => {
      if (audio) audio.volume = vol;
    });
  }
}

export default SoundManager;

// הטענה מראש בתחילת האפליקציה (ב-App.tsx)