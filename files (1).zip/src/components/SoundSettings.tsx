import React from "react";
import SoundManager from "../SoundManager";

export default function SoundSettings() {
  const [volume, setVolume] = React.useState(SoundManager.volume);

  function onChange(e: React.ChangeEvent<HTMLInputElement>) {
    const v = parseFloat(e.target.value);
    setVolume(v);
    SoundManager.setVolume(v);
  }

  return (
    <div style={{margin:"10px 0"}}>
      <label>🔊 עוצמת סאונד:
        <input type="range" min="0" max="1" step="0.05" value={volume}
               onChange={onChange} style={{margin:"0 10px"}}/>
        {Math.round(volume * 100)}%
      </label>
    </div>
  );
}