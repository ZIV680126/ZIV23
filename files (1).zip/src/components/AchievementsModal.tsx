import React from "react";
import styled, { keyframes } from "styled-components";
import { useGame } from "../GameContext";
import { allAchievements } from "../gameData";

const fadein = keyframes`
  from { opacity: 0; }
  to { opacity: 1; }
`;

const ModalBg = styled.div`
  position: fixed;
  z-index: 500;
  left: 0; top: 0; right: 0; bottom: 0;
  background: #333a;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: ${fadein} .5s;
`;

const ModalBox = styled.div`
  background: #fff;
  border-radius: 18px;
  min-width: 330px;
  padding: 24px 22px;
  box-shadow: 0 4px 18px #0002;
  text-align: center;
`;

const AchvRow = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 11px;
  font-size: 1.15rem;
`;

const Emoji = styled.span`
  font-size: 2rem;
  margin-left: 15px;
`;

const CloseBtn = styled.button`
  background: #81d4fa;
  color: #222;
  font-size: 1.08rem;
  padding: 8px 25px;
  border-radius: 18px;
  margin-top: 16px;
  border: none;
`;

export default function AchievementsModal({ onClose }: { onClose: () => void }) {
  const { gameState } = useGame();
  const { user } = gameState;

  return (
    <ModalBg>
      <ModalBox>
        <h2>🎖️ תגי הישגים</h2>
        {allAchievements.map(ach =>
          <AchvRow key={ach.key}>
            <Emoji>{ach.emoji}</Emoji>
            <div>
              <b>{ach.label}</b>
              <div style={{ fontSize: ".98rem", color: "#223" }}>{ach.desc}</div>
              {user?.achievements.includes(ach.key) ? <span style={{ color: "#2ebf91" }}>נפתח!</span> : <span style={{ color: "#ccc" }}>לא נעול</span>}
            </div>
          </AchvRow>
        )}
        <CloseBtn onClick={onClose}>סגור</CloseBtn>
      </ModalBox>
    </ModalBg>
  );
}