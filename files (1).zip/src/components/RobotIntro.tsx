import React, { useEffect } from "react";
import styled, { keyframes } from "styled-components";
import { useGame } from "../GameContext";
import robotImg from "../assets/robot.png"; // ניתן להחליף בתמונה מתאימה

const wave = keyframes`
  0% { transform: rotate(0deg);}
  30% { transform: rotate(-20deg);}
  60% { transform: rotate(15deg);}
  100% { transform: rotate(0deg);}
`;

const RobotContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 430px;
  background: #e1f5fe;
`;

const RobotImage = styled.img`
  width: 140px;
  margin-bottom: 16px;
  animation: ${wave} 2s linear 1;
`;

const WelcomeText = styled.h2`
  font-size: 2rem;
  color: #2176ae;
`;

export default function RobotIntro() {
  const { gameState } = useGame();
  const { setShowRobotIntro } = gameState;

  useEffect(() => {
    setTimeout(() => {
      setShowRobotIntro(false);
    }, 2700);
  }, []);
  return (
    <RobotContainer>
      <RobotImage src={robotImg} alt="robot" />
      <WelcomeText>שלום! אני הרובוט של Math GO!</WelcomeText>
    </RobotContainer>
  );
}