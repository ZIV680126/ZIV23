import React, { createContext, useContext, useEffect, useState } from "react";
import { Question, Level, Stage, getAllLevels, Achievement, allAchievements, ShopItem, shopItems } from "./gameData";
import { loadUser, saveUser, UserState, newUserState } from "./userStorage";
import SoundManager from "./SoundManager";

type Screen = "home" | "level-select" | "stage" | "shop";
type GameContextType = {
  gameState: {
    screen: Screen;
    user: UserState | null;
    currentLevel: number;
    currentStage: number;
    showAchievements: boolean;
    setShowAchievements: (b: boolean) => void;
    showRobotIntro: boolean;
    setShowRobotIntro: (b: boolean) => void;
  };
  setUser: (u: UserState|null) => void;
  setScreen: (s: Screen) => void;
  setCurrentLevel: (n: number) => void;
  setCurrentStage: (n: number) => void;
  updateUser: (u: Partial<UserState>) => void;
  reloadUser: (name: string) => void;
};

const GameContext = createContext<GameContextType | null>(null);

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [screen, setScreen] = useState<Screen>("home");
  const [showAchievements, setShowAchievements] = useState(false);
  const [showRobotIntro, setShowRobotIntro] = useState(true);
  const [user, setUser] = useState<UserState | null>(null);
  const [currentLevel, setCurrentLevel] = useState(0);
  const [currentStage, setCurrentStage] = useState(0);

  useEffect(() => {
    if (user) saveUser(user);
  }, [user]);

  function reloadUser(name: string) {
    const loaded = loadUser(name);
    setUser(loaded);
  }

  function updateUser(u: Partial<UserState>) {
    setUser(prev => prev ? { ...prev, ...u } : prev);
  }

  const value = {
    gameState: {
      screen,
      user,
      currentLevel,
      currentStage,
      showAchievements,
      setShowAchievements,
      showRobotIntro,
      setShowRobotIntro,
    },
    setUser,
    setScreen,
    setCurrentLevel,
    setCurrentStage,
    updateUser,
    reloadUser,
  };

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGame() {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error("useGame must be used within GameProvider");
  return ctx;
}